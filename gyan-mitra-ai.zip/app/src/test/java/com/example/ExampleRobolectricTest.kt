package com.example

import com.example.data.model.AssistantCategory
import com.example.data.model.Language
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class DomainLogicTest {

    @Test
    fun testLanguageCodes() {
        assertEquals(Language.ENGLISH, Language.fromCode("en"))
        assertEquals(Language.HINDI, Language.fromCode("hi"))
        assertEquals(Language.HINGLISH, Language.fromCode("hi-Latn"))
        assertEquals(Language.ENGLISH, Language.fromCode("unknown"))
    }

    @Test
    fun testAssistantCategories() {
        assertEquals(5, AssistantCategory.entries.size)
        assertNotNull(AssistantCategory.valueOf("GENERAL"))
        assertNotNull(AssistantCategory.valueOf("WRITING"))
        assertNotNull(AssistantCategory.valueOf("CODING"))
        assertNotNull(AssistantCategory.valueOf("MATHEMATICS"))
        assertNotNull(AssistantCategory.valueOf("STUDY_RESEARCH"))
    }
}
