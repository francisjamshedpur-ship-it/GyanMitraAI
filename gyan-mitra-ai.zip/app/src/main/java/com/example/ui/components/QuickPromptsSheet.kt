package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AssistantCategory

data class QuickPrompt(val title: String, val prompt: String, val category: AssistantCategory)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickPromptsSheet(
    onPromptSelected: (QuickPrompt) -> Unit,
    onDismissRequest: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTabIndex by remember { mutableIntStateOf(0) }

    val categories = listOf(
        AssistantCategory.WRITING,
        AssistantCategory.CODING,
        AssistantCategory.MATHEMATICS,
        AssistantCategory.STUDY_RESEARCH
    )

    val allPrompts = listOf(
        // Writing
        QuickPrompt("Leave Application Email", "Write a professional leave application email to my manager for 2 days due to a family emergency.", AssistantCategory.WRITING),
        QuickPrompt("Hindi Poem (कविता)", "आशा और आत्मविश्वास पर एक प्रेरक हिंदी कविता (कविता) लिखें।", AssistantCategory.WRITING),
        QuickPrompt("Cover Letter for Job", "Draft a compelling cover letter for a junior software engineer position highlighting problem-solving skills.", AssistantCategory.WRITING),
        QuickPrompt("Hinglish Social Post", "Ek engaging Hinglish Instagram caption likhiye about learning consistency aur daily habits.", AssistantCategory.WRITING),

        // Coding
        QuickPrompt("Python Algorithm", "Write an optimized Python program to find the longest substring without repeating characters with explanation.", AssistantCategory.CODING),
        QuickPrompt("Kotlin Coroutines Error", "Explain how Kotlin Coroutine ExceptionHandler works and how to avoid crashes in launch vs async.", AssistantCategory.CODING),
        QuickPrompt("JavaScript Fetch Retry", "Write a clean JavaScript async function with exponential backoff retry logic for API calls.", AssistantCategory.CODING),
        QuickPrompt("SQL Top Salaries", "Write a SQL query to find the 2nd highest salary in each department using Window Functions.", AssistantCategory.CODING),

        // Mathematics
        QuickPrompt("Quadratic Equation Steps", "Solve the quadratic equation 3x^2 - 5x + 2 = 0 step-by-step showing the discriminant.", AssistantCategory.MATHEMATICS),
        QuickPrompt("Calculus Derivative", "Find the derivative of f(x) = sin(x) * e^(2x) using the product rule and chain rule.", AssistantCategory.MATHEMATICS),
        QuickPrompt("Definite Integral", "Evaluate the definite integral of 1 / (1 + x^2) from 0 to 1 with detailed steps.", AssistantCategory.MATHEMATICS),
        QuickPrompt("Matrix Multiplication", "Explain how 2x2 matrix multiplication works with a clear numerical example.", AssistantCategory.MATHEMATICS),

        // Study & Research
        QuickPrompt("Feynman Technique: Quantum", "Explain Quantum Computing using the Feynman technique so a 12-year-old can easily understand it.", AssistantCategory.STUDY_RESEARCH),
        QuickPrompt("Study Flashcards: History", "Generate 5 active-recall flashcards with questions and answers on the Indian Independence Movement.", AssistantCategory.STUDY_RESEARCH),
        QuickPrompt("5-Question Quiz: Science", "Create a 5-question multiple choice quiz on Photosynthesis with answers and explanations.", AssistantCategory.STUDY_RESEARCH),
        QuickPrompt("Exam Revision Timetable", "Create a balanced 7-day study timetable for final semester exams with breaks and revision slots.", AssistantCategory.STUDY_RESEARCH)
    )

    val currentPrompts = allPrompts.filter { it.category == categories[selectedTabIndex] }

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Gyan Mitra AI Tools & Prompts",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            TabRow(selectedTabIndex = selectedTabIndex) {
                categories.forEachIndexed { index, cat ->
                    val icon = when (cat) {
                        AssistantCategory.WRITING -> Icons.Default.Edit
                        AssistantCategory.CODING -> Icons.Default.Code
                        AssistantCategory.MATHEMATICS -> Icons.Default.Calculate
                        AssistantCategory.STUDY_RESEARCH -> Icons.Default.School
                        else -> Icons.Default.AutoAwesome
                    }
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(cat.title.split(" ").first()) },
                        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(currentPrompts) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onPromptSelected(item)
                                onDismissRequest()
                            }
                            .testTag("quick_prompt_${item.title.lowercase().replace(" ", "_")}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = item.prompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForwardIos,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
