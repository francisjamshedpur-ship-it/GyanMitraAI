package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AssistantCategory
import com.example.data.model.Language
import com.example.ui.components.AssistantCategoryChips
import com.example.ui.components.ChatDrawerContent
import com.example.ui.components.ChatInputBar
import com.example.ui.components.ChatMessageItem
import com.example.ui.components.LanguageSelectorDialog
import com.example.ui.components.QuickPromptsSheet
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // ViewModel States
    val sessions by viewModel.allSessions.collectAsState()
    val currentSession by viewModel.currentSession.collectAsState()
    val messages by viewModel.currentMessages.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val attachedImageUri by viewModel.attachedImageUri.collectAsState()
    val attachedDocument by viewModel.attachedDocument.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val streamingMessage by viewModel.streamingMessage.collectAsState()
    val showNoticeBanner by viewModel.showNoticeBanner.collectAsState()
    val speakingId by viewModel.ttsManager.currentlySpeakingId.collectAsState()

    // Dialog & Sheet States
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showQuickPromptsSheet by remember { mutableStateOf(false) }

    // Scroll to bottom on new messages
    LaunchedEffect(messages.size, streamingMessage?.content) {
        val totalCount = messages.size + if (streamingMessage != null) 1 else 0
        if (totalCount > 0) {
            listState.animateScrollToItem(totalCount - 1)
        }
    }

    // Handle Back Press to close drawer if open
    BackHandler(enabled = drawerState.isOpen) {
        coroutineScope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                ChatDrawerContent(
                    sessions = sessions,
                    currentSessionId = currentSession?.id,
                    onSessionSelected = { id ->
                        viewModel.selectSession(id)
                        coroutineScope.launch { drawerState.close() }
                    },
                    onNewChatClicked = {
                        viewModel.createNewSession()
                        coroutineScope.launch { drawerState.close() }
                    },
                    onDeleteSession = { id -> viewModel.deleteSession(id) },
                    onClearAllClicked = {
                        viewModel.clearAllSessions()
                        coroutineScope.launch { drawerState.close() }
                    },
                    currentThemeMode = themeMode,
                    onThemeModeChanged = { mode -> viewModel.setThemeMode(mode) }
                )
            }
        }
    ) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "Gyan Mitra AI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${selectedLanguage.nativeName} • ${selectedCategory.title}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("open_drawer_button")
                        ) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Open Drawer")
                        }
                    },
                    actions = {
                        // Quick Prompts / Tools Button
                        IconButton(
                            onClick = { showQuickPromptsSheet = true },
                            modifier = Modifier.testTag("quick_prompts_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.TipsAndUpdates,
                                contentDescription = "Quick Prompts",
                                tint = MaterialTheme.colorScheme.secondary
                            )
                        }

                        // Language Selector Button
                        IconButton(
                            onClick = { showLanguageDialog = true },
                            modifier = Modifier.testTag("language_selector_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Switch Language",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        // New Chat Button
                        IconButton(
                            onClick = { viewModel.createNewSession() },
                            modifier = Modifier.testTag("new_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "New Chat",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                ChatInputBar(
                    inputText = inputText,
                    onInputChanged = { viewModel.onInputTextChanged(it) },
                    onSendClicked = { viewModel.sendMessage() },
                    isGenerating = isGenerating,
                    attachedImageUri = attachedImageUri,
                    attachedDocument = attachedDocument,
                    onImageSelected = { viewModel.setAttachedImage(it) },
                    onDocumentSelected = { viewModel.setAttachedDocument(it) },
                    onClearAttachments = { viewModel.clearAttachments() },
                    selectedLanguage = selectedLanguage
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Notice Banner (In-app notice explaining offline mode when Firebase is not active)
                AnimatedVisibility(visible = showNoticeBanner) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Gyan Mitra AI running in offline intelligent mode. Cloud Gemini live features require Firebase.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.dismissNoticeBanner() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss notice",
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Assistant Category Switcher
                AssistantCategoryChips(
                    selectedCategory = selectedCategory,
                    onCategorySelected = { cat ->
                        viewModel.setCategory(cat)
                    }
                )

                // Message List or Empty State Welcome Hero
                if (messages.isEmpty() && streamingMessage == null) {
                    EmptyChatWelcomeHero(
                        selectedLanguage = selectedLanguage,
                        selectedCategory = selectedCategory,
                        onQuickPromptClicked = { promptText ->
                            viewModel.sendMessage(promptText)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        items(messages, key = { it.id }) { message ->
                            ChatMessageItem(
                                message = message,
                                isSpeaking = speakingId == message.id,
                                onSpeakClick = { viewModel.speakMessage(message) },
                                onStopSpeakClick = { viewModel.stopSpeaking() }
                            )
                        }

                        // Currently streaming chunk
                        streamingMessage?.let { streamMsg ->
                            item(key = "streaming_message") {
                                ChatMessageItem(
                                    message = streamMsg,
                                    isSpeaking = false,
                                    onSpeakClick = {},
                                    onStopSpeakClick = {}
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Language Selector Dialog
    if (showLanguageDialog) {
        LanguageSelectorDialog(
            currentLanguage = selectedLanguage,
            onLanguageSelected = { lang -> viewModel.setLanguage(lang) },
            onDismissRequest = { showLanguageDialog = false }
        )
    }

    // Quick Prompts Sheet
    if (showQuickPromptsSheet) {
        QuickPromptsSheet(
            onPromptSelected = { quickPrompt ->
                viewModel.setCategory(quickPrompt.category)
                viewModel.sendMessage(quickPrompt.prompt)
            },
            onDismissRequest = { showQuickPromptsSheet = false }
        )
    }
}

@Composable
fun EmptyChatWelcomeHero(
    selectedLanguage: Language,
    selectedCategory: AssistantCategory,
    onQuickPromptClicked: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val welcomeHeading = when (selectedLanguage) {
        Language.HINDI -> "नमस्ते! मैं ज्ञान मित्र AI हूँ"
        Language.HINGLISH -> "Namaste! Main Gyan Mitra AI hoon"
        Language.ENGLISH -> "Hello! I am Gyan Mitra AI"
    }

    val welcomeSub = when (selectedLanguage) {
        Language.HINDI -> "हिंदी, English और Hinglish में आपका बुद्धिमान अध्ययन, कोडिंग और रचनात्मक साथी।"
        Language.HINGLISH -> "Aapka smart companion for Study, Coding, Writing aur Math problem solving."
        Language.ENGLISH -> "Your intelligent multilingual companion for learning, writing, coding, and problem solving."
    }

    val sampleStarters = when (selectedCategory) {
        AssistantCategory.WRITING -> listOf(
            "Write a formal leave application email",
            "हिंदी में प्रेरणादायक कविता (कविता) लिखें",
            "Draft a compelling cover letter for my resume"
        )
        AssistantCategory.CODING -> listOf(
            "Explain Python algorithms with clean code",
            "Kotlin Coroutines error handling best practices",
            "Write SQL query to find top department salaries"
        )
        AssistantCategory.MATHEMATICS -> listOf(
            "Solve quadratic equation 3x² - 5x + 2 = 0 step-by-step",
            "Find derivative of f(x) = sin(x) * e^(2x)",
            "Explain integration by parts formula with example"
        )
        AssistantCategory.STUDY_RESEARCH -> listOf(
            "Explain Quantum Computing in simple terms",
            "Generate 5 active-recall flashcards for history",
            "Create a 7-day exam revision timetable"
        )
        AssistantCategory.GENERAL -> listOf(
            "Explain artificial intelligence in simple Hindi",
            "Tips for effective time management & study habits",
            "Compare classical and quantum physics"
        )
    }

    Column(
        modifier = modifier
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Hero Emblem
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer)
                .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(38.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = welcomeHeading,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = welcomeSub,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 20.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Try asking / सुझाव:",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            sampleStarters.forEach { prompt ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onQuickPromptClicked(prompt) }
                        .testTag("welcome_starter_chip"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.TipsAndUpdates,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = prompt,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
