package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.model.AssistantCategory
import com.example.data.model.Language
import com.example.data.repository.AiRepository
import com.example.data.repository.AiRepositoryImpl
import com.example.ui.theme.ThemeMode
import com.example.util.DocumentHelper
import com.example.util.TtsManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = "ChatViewModel"
    private val database = AppDatabase.getDatabase(application)
    private val chatDao = database.chatDao()
    private val aiRepository: AiRepository = AiRepositoryImpl(application)
    val ttsManager = TtsManager(application)

    // Sessions History Flow
    val allSessions: StateFlow<List<ChatSessionEntity>> = chatDao.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Current Session State
    private val _currentSession = MutableStateFlow<ChatSessionEntity?>(null)
    val currentSession: StateFlow<ChatSessionEntity?> = _currentSession.asStateFlow()

    // Current Session Messages Flow
    private val _currentMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentMessages.asStateFlow()

    // Input States
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    // Selected Language
    private val _selectedLanguage = MutableStateFlow(Language.ENGLISH)
    val selectedLanguage: StateFlow<Language> = _selectedLanguage.asStateFlow()

    // Selected Assistant Category
    private val _selectedCategory = MutableStateFlow(AssistantCategory.GENERAL)
    val selectedCategory: StateFlow<AssistantCategory> = _selectedCategory.asStateFlow()

    // App Theme Mode
    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Attachments
    private val _attachedImageUri = MutableStateFlow<Uri?>(null)
    val attachedImageUri: StateFlow<Uri?> = _attachedImageUri.asStateFlow()

    private val _attachedDocument = MutableStateFlow<DocumentHelper.DocumentInfo?>(null)
    val attachedDocument: StateFlow<DocumentHelper.DocumentInfo?> = _attachedDocument.asStateFlow()

    // Generation / Streaming State
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingMessage = MutableStateFlow<ChatMessageEntity?>(null)
    val streamingMessage: StateFlow<ChatMessageEntity?> = _streamingMessage.asStateFlow()

    // Banner visibility
    private val _showNoticeBanner = MutableStateFlow(!aiRepository.isFirebaseConfigured)
    val showNoticeBanner: StateFlow<Boolean> = _showNoticeBanner.asStateFlow()

    private var activeGenerationJob: Job? = null
    private var messagesObserverJob: Job? = null

    init {
        viewModelScope.launch {
            // Load latest session or create a new one
            allSessions.collect { sessions ->
                if (_currentSession.value == null) {
                    if (sessions.isNotEmpty()) {
                        selectSession(sessions.first().id)
                    } else {
                        createNewSession()
                    }
                }
            }
        }
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    fun setLanguage(language: Language) {
        _selectedLanguage.value = language
        _currentSession.value?.let { session ->
            viewModelScope.launch {
                val updated = session.copy(languageCode = language.code, updatedAt = System.currentTimeMillis())
                chatDao.updateSession(updated)
                _currentSession.value = updated
            }
        }
    }

    fun setCategory(category: AssistantCategory) {
        _selectedCategory.value = category
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun setAttachedImage(uri: Uri?) {
        _attachedImageUri.value = uri
    }

    fun setAttachedDocument(doc: DocumentHelper.DocumentInfo?) {
        _attachedDocument.value = doc
    }

    fun clearAttachments() {
        _attachedImageUri.value = null
        _attachedDocument.value = null
    }

    fun dismissNoticeBanner() {
        _showNoticeBanner.value = false
    }

    fun selectSession(sessionId: String) {
        viewModelScope.launch {
            val session = chatDao.getSessionById(sessionId)
            if (session != null) {
                _currentSession.value = session
                _selectedLanguage.value = Language.fromCode(session.languageCode)
                _selectedCategory.value = try {
                    AssistantCategory.valueOf(session.category)
                } catch (e: Exception) {
                    AssistantCategory.GENERAL
                }
                observeMessagesForSession(sessionId)
            }
        }
    }

    private fun observeMessagesForSession(sessionId: String) {
        messagesObserverJob?.cancel()
        messagesObserverJob = viewModelScope.launch {
            chatDao.getMessagesForSession(sessionId).collect { messages ->
                _currentMessages.value = messages
            }
        }
    }

    fun createNewSession(category: AssistantCategory = _selectedCategory.value) {
        viewModelScope.launch {
            val title = when (_selectedLanguage.value) {
                Language.HINDI -> "नया वार्तालाप"
                Language.HINGLISH -> "New Conversation"
                Language.ENGLISH -> "New Conversation"
            }
            val newSession = ChatSessionEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                languageCode = _selectedLanguage.value.code,
                category = category.name
            )
            chatDao.insertSession(newSession)
            _currentSession.value = newSession
            _selectedCategory.value = category
            observeMessagesForSession(newSession.id)
            clearAttachments()
            _inputText.value = ""
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            chatDao.deleteSessionById(sessionId)
            if (_currentSession.value?.id == sessionId) {
                _currentSession.value = null
                _currentMessages.value = emptyList()
            }
        }
    }

    fun clearAllSessions() {
        viewModelScope.launch {
            ttsManager.stop()
            chatDao.deleteAllSessions()
            _currentSession.value = null
            _currentMessages.value = emptyList()
            createNewSession()
        }
    }

    fun sendMessage(promptOverride: String? = null) {
        val prompt = (promptOverride ?: _inputText.value).trim()
        val imageUriStr = _attachedImageUri.value?.toString()
        val docInfo = _attachedDocument.value

        if (prompt.isEmpty() && imageUriStr == null && docInfo == null) return

        val session = _currentSession.value ?: return
        val effectivePrompt = if (prompt.isEmpty()) {
            if (imageUriStr != null) "कृपया इस चित्र का विश्लेषण करें" else "कृपया इस दस्तावेज़ का विश्लेषण करें"
        } else prompt

        viewModelScope.launch {
            // 1. Insert User Message
            val userMsg = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                sessionId = session.id,
                role = "user",
                content = effectivePrompt,
                imageUri = imageUriStr,
                docName = docInfo?.name,
                docSnippet = docInfo?.extractedText,
                languageCode = _selectedLanguage.value.code
            )
            chatDao.insertMessage(userMsg)

            // Update session title if first message
            if (_currentMessages.value.isEmpty()) {
                val derivedTitle = if (effectivePrompt.length > 30) {
                    effectivePrompt.take(28) + "..."
                } else effectivePrompt
                val updatedSession = session.copy(
                    title = derivedTitle,
                    updatedAt = System.currentTimeMillis()
                )
                chatDao.updateSession(updatedSession)
                _currentSession.value = updatedSession
            } else {
                chatDao.updateSession(session.copy(updatedAt = System.currentTimeMillis()))
            }

            // Clear input & attachments
            _inputText.value = ""
            clearAttachments()

            // 2. Prepare Assistant Message Stream
            _isGenerating.value = true
            val assistantMsgId = UUID.randomUUID().toString()
            val streamingMsg = ChatMessageEntity(
                id = assistantMsgId,
                sessionId = session.id,
                role = "assistant",
                content = "",
                languageCode = _selectedLanguage.value.code
            )
            _streamingMessage.value = streamingMsg

            activeGenerationJob = launch {
                try {
                    val streamFlow = aiRepository.generateResponseStream(
                        prompt = effectivePrompt,
                        history = _currentMessages.value + userMsg,
                        language = _selectedLanguage.value,
                        category = _selectedCategory.value,
                        imageUri = imageUriStr,
                        documentSnippet = docInfo?.extractedText
                    )

                    var latestContent = ""
                    streamFlow.collect { accumulatedText ->
                        latestContent = accumulatedText
                        _streamingMessage.value = streamingMsg.copy(content = accumulatedText)
                    }

                    // Save final message in Room
                    if (latestContent.isNotEmpty()) {
                        val finalMsg = streamingMsg.copy(content = latestContent)
                        chatDao.insertMessage(finalMsg)
                    }
                } catch (e: Exception) {
                    Log.e(tag, "Generation error", e)
                    val errorMsg = streamingMsg.copy(
                        content = "त्रुटि / Error: " + (e.localizedMessage ?: "Failed to generate response"),
                        isError = true
                    )
                    chatDao.insertMessage(errorMsg)
                } finally {
                    _streamingMessage.value = null
                    _isGenerating.value = false
                }
            }
        }
    }

    fun speakMessage(message: ChatMessageEntity) {
        val lang = Language.fromCode(message.languageCode)
        ttsManager.speak(message.id, message.content, lang)
    }

    fun stopSpeaking() {
        ttsManager.stop()
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        activeGenerationJob?.cancel()
    }
}
