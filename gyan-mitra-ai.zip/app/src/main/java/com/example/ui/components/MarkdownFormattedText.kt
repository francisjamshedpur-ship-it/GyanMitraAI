package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MarkdownFormattedText(
    text: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        val blocks = parseContentBlocks(text)
        for (block in blocks) {
            when (block) {
                is ContentBlock.Code -> {
                    CodeBlockView(language = block.language, code = block.code)
                }
                is ContentBlock.Header -> {
                    Text(
                        text = block.text,
                        style = if (block.level == 1) MaterialTheme.typography.titleLarge
                        else if (block.level == 2) MaterialTheme.typography.titleMedium
                        else MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    )
                }
                is ContentBlock.Quote -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(28.dp)
                                .background(MaterialTheme.colorScheme.secondary, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = block.text,
                            style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                is ContentBlock.Paragraph -> {
                    Text(
                        text = buildAnnotatedParagraph(block.text, textColor),
                        style = MaterialTheme.typography.bodyLarge,
                        lineHeight = 22.sp
                    )
                }
            }
        }
    }
}

private sealed interface ContentBlock {
    data class Code(val language: String, val code: String) : ContentBlock
    data class Header(val level: Int, val text: String) : ContentBlock
    data class Quote(val text: String) : ContentBlock
    data class Paragraph(val text: String) : ContentBlock
}

private fun parseContentBlocks(raw: String): List<ContentBlock> {
    val result = mutableListOf<ContentBlock>()
    val lines = raw.lines()
    var inCodeBlock = false
    var codeLang = ""
    val codeBuilder = StringBuilder()
    val paragraphBuilder = StringBuilder()

    fun flushParagraph() {
        if (paragraphBuilder.isNotBlank()) {
            result.add(ContentBlock.Paragraph(paragraphBuilder.toString().trim()))
            paragraphBuilder.clear()
        }
    }

    for (line in lines) {
        val trimmed = line.trim()
        if (trimmed.startsWith("```")) {
            if (inCodeBlock) {
                result.add(ContentBlock.Code(codeLang, codeBuilder.toString().trimEnd()))
                codeBuilder.clear()
                inCodeBlock = false
                codeLang = ""
            } else {
                flushParagraph()
                inCodeBlock = true
                codeLang = trimmed.removePrefix("```").trim()
            }
        } else if (inCodeBlock) {
            codeBuilder.append(line).append("\n")
        } else if (trimmed.startsWith("### ")) {
            flushParagraph()
            result.add(ContentBlock.Header(3, trimmed.removePrefix("### ").trim()))
        } else if (trimmed.startsWith("## ")) {
            flushParagraph()
            result.add(ContentBlock.Header(2, trimmed.removePrefix("## ").trim()))
        } else if (trimmed.startsWith("# ")) {
            flushParagraph()
            result.add(ContentBlock.Header(1, trimmed.removePrefix("# ").trim()))
        } else if (trimmed.startsWith("> ")) {
            flushParagraph()
            result.add(ContentBlock.Quote(trimmed.removePrefix("> ").trim()))
        } else {
            if (line.isBlank()) {
                flushParagraph()
            } else {
                if (paragraphBuilder.isNotEmpty()) paragraphBuilder.append("\n")
                paragraphBuilder.append(line)
            }
        }
    }

    if (inCodeBlock && codeBuilder.isNotEmpty()) {
        result.add(ContentBlock.Code(codeLang, codeBuilder.toString().trimEnd()))
    }
    flushParagraph()

    return result
}

@Composable
fun CodeBlockView(language: String, code: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val headerLabel = if (language.isNotBlank()) language.uppercase() else "CODE"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F172A))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
    ) {
        // Code Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E293B))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = headerLabel,
                color = Color(0xFF38BDF8),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
            )
            IconButton(
                onClick = {
                    clipboard.setText(AnnotatedString(code))
                    Toast.makeText(context, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("copy_code_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy code",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Code Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Text(
                text = code,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = Color(0xFFE2E8F0),
                lineHeight = 18.sp
            )
        }
    }
}

private fun buildAnnotatedParagraph(text: String, defaultColor: Color): AnnotatedString {
    return buildAnnotatedString {
        var currentIndex = 0
        // Match bold **text** or inline `code`
        val regex = Regex("(\\*{2}(.+?)\\*{2})|(`([^`]+?)`)")
        val matches = regex.findAll(text)

        for (match in matches) {
            if (match.range.first > currentIndex) {
                withStyle(SpanStyle(color = defaultColor)) {
                    append(text.substring(currentIndex, match.range.first))
                }
            }

            val fullMatch = match.value
            if (fullMatch.startsWith("**") && fullMatch.endsWith("**")) {
                val boldText = fullMatch.substring(2, fullMatch.length - 2)
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = defaultColor)) {
                    append(boldText)
                }
            } else if (fullMatch.startsWith("`") && fullMatch.endsWith("`")) {
                val inlineCode = fullMatch.substring(1, fullMatch.length - 1)
                withStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF0284C7),
                        background = Color(0xFFE0F2FE)
                    )
                ) {
                    append(" $inlineCode ")
                }
            }
            currentIndex = match.range.last + 1
        }

        if (currentIndex < text.length) {
            withStyle(SpanStyle(color = defaultColor)) {
                append(text.substring(currentIndex))
            }
        }
    }
}
