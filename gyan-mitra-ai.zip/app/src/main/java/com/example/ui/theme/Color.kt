package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gyan Mitra Brand Colors
val SaffronPrimary = Color(0xFFE65100)
val SaffronDark = Color(0xFFFF8F00)
val TealGlow = Color(0xFF00B4D8)
val TealAccent = Color(0xFF0077B6)
val GoldenSpark = Color(0xFFF59E0B)

// Dark Theme Colors
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF121A2D)
val DarkSurfaceVariant = Color(0xFF1B253E)
val DarkPrimary = Color(0xFF38BDF8)
val DarkOnPrimary = Color(0xFF082F49)
val DarkSecondary = Color(0xFFFBBF24)
val DarkOnSecondary = Color(0xFF451A03)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF263352)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightPrimary = Color(0xFF0284C7)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightSecondary = Color(0xFFD97706)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
val LightBorder = Color(0xFFE2E8F0)

// Specialized Accent Badges
val WritingAccent = Color(0xFF8B5CF6)
val CodingAccent = Color(0xFF10B981)
val MathAccent = Color(0xFFEC4899)
val StudyAccent = Color(0xFFF59E0B)
