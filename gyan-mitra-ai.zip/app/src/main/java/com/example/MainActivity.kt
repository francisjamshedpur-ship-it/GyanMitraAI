package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.MainChatScreen
import com.example.ui.theme.GyanMitraTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {

    private val chatViewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        // STEP 2: Edge-to-edge support
        enableEdgeToEdge()

        // STEP 3: Initialize UI
        setContent {
            val themeMode by chatViewModel.themeMode.collectAsState()
            GyanMitraTheme(themeMode = themeMode) {
                MainChatScreen(viewModel = chatViewModel)
            }
        }
    }
}
