package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.Language
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsManager(context: Context) {
    private val tag = "TtsManager"
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _currentlySpeakingId = MutableStateFlow<String?>(null)
    val currentlySpeakingId: StateFlow<String?> = _currentlySpeakingId.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _currentlySpeakingId.value = utteranceId
                    }

                    override fun onDone(utteranceId: String?) {
                        if (_currentlySpeakingId.value == utteranceId) {
                            _currentlySpeakingId.value = null
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (_currentlySpeakingId.value == utteranceId) {
                            _currentlySpeakingId.value = null
                        }
                    }
                })
            } else {
                Log.e(tag, "Failed to initialize TextToSpeech: status=$status")
            }
        }
    }

    fun speak(messageId: String, text: String, language: Language) {
        if (!isInitialized || tts == null) {
            Log.w(tag, "TTS not initialized yet")
            return
        }

        // Clean markdown symbols for natural speech
        val cleanedText = cleanTextForSpeech(text)
        if (cleanedText.isBlank()) return

        val locale = when (language) {
            Language.HINDI -> Locale("hi", "IN")
            Language.HINGLISH -> Locale("hi", "IN")
            Language.ENGLISH -> Locale("en", "IN")
        }

        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to English if Hindi voice is not installed
            tts?.setLanguage(Locale.US)
        }

        _currentlySpeakingId.value = messageId
        tts?.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, null, messageId)
    }

    fun stop() {
        tts?.stop()
        _currentlySpeakingId.value = null
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
            _currentlySpeakingId.value = null
        } catch (e: Exception) {
            Log.e(tag, "Error shutting down TTS", e)
        }
    }

    private fun cleanTextForSpeech(markdown: String): String {
        return markdown
            .replace(Regex("```[a-zA-Z]*\\n[\\s\\S]*?```"), "Code block omitted.")
            .replace(Regex("`([^`]+)`"), "$1")
            .replace(Regex("[#*_~]"), "")
            .replace(Regex("\\[([^\\]]+)\\]\\([^\\)]+\\)"), "$1")
            .replace(Regex("\\n+"), ". ")
            .trim()
    }
}
