package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader

object DocumentHelper {
    private const val TAG = "DocumentHelper"

    data class DocumentInfo(
        val name: String,
        val size: Long,
        val mimeType: String?,
        val extractedText: String
    )

    fun readDocument(context: Context, uri: Uri): DocumentInfo {
        var name = "Document"
        var size: Long = 0
        val mimeType = context.contentResolver.getType(uri)

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex) ?: name
                    if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting document metadata", e)
        }

        val textBuilder = StringBuilder()
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
                var line: String?
                var linesRead = 0
                while (reader.readLine().also { line = it } != null && linesRead < 300) {
                    textBuilder.append(line).append("\n")
                    linesRead++
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading document text", e)
        }

        var extracted = textBuilder.toString().trim()
        if (extracted.isBlank()) {
            extracted = "Document '$name' (${size / 1024} KB, format: ${mimeType ?: "PDF/binary"}). Ready for comprehensive AI analysis."
        } else if (extracted.length > 4000) {
            extracted = extracted.substring(0, 4000) + "\n...[truncated for analysis]"
        }

        return DocumentInfo(
            name = name,
            size = size,
            mimeType = mimeType,
            extractedText = extracted
        )
    }
}
