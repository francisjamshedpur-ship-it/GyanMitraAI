package com.example.data.model

enum class Language(val displayName: String, val nativeName: String, val code: String) {
    ENGLISH("English", "English", "en"),
    HINDI("Hindi", "हिंदी", "hi"),
    HINGLISH("Hinglish", "Hinglish (हिंदी + Eng)", "hi-Latn");

    companion object {
        fun fromCode(code: String): Language {
            return entries.firstOrNull { it.code == code } ?: ENGLISH
        }
    }
}

enum class AssistantCategory(val title: String, val subtitle: String, val iconName: String) {
    GENERAL("All-Rounder", "Ask anything in your preferred language", "chat"),
    WRITING("Writing Assistant", "Emails, essays, letters, poems & posts", "edit"),
    CODING("Coding Assistant", "Code, debug, optimize & explain logic", "code"),
    MATHEMATICS("Math Solver", "Step-by-step calculus, algebra & formulas", "calculate"),
    STUDY_RESEARCH("Study & Research", "Summaries, flashcards, quizzes & notes", "school")
}
