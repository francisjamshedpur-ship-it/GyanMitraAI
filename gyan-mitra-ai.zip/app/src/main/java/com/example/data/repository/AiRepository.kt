package com.example.data.repository

import com.example.data.local.ChatMessageEntity
import com.example.data.model.AssistantCategory
import com.example.data.model.Language
import kotlinx.coroutines.flow.Flow

interface AiRepository {
    val isFirebaseConfigured: Boolean

    fun generateResponseStream(
        prompt: String,
        history: List<ChatMessageEntity>,
        language: Language,
        category: AssistantCategory,
        imageUri: String? = null,
        documentSnippet: String? = null
    ): Flow<String>
}
